package com.example.eeducation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
